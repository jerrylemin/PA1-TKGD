# Graph Report - PA4  (2026-08-23)

## Corpus Check
- 65 files · ~119,365 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 773 nodes · 1122 edges · 61 communities (56 shown, 5 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 64 edges (avg confidence: 0.83)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `b6f6bde`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Continuity and Gates|Continuity and Gates]]
- [[_COMMUNITY_Study Analyzer Code|Study Analyzer Code]]
- [[_COMMUNITY_FIFA Event Overview|FIFA Event Overview]]
- [[_COMMUNITY_Chess Practice Completion|Chess Practice Completion]]
- [[_COMMUNITY_Chess Trial Interface|Chess Trial Interface]]
- [[_COMMUNITY_Chess Prototype Logic|Chess Prototype Logic]]
- [[_COMMUNITY_Chess Practice Screen|Chess Practice Screen]]
- [[_COMMUNITY_Current Memory Documents|Current Memory Documents]]
- [[_COMMUNITY_Report Generation Code|Report Generation Code]]
- [[_COMMUNITY_Study Evidence Fields|Study Evidence Fields]]
- [[_COMMUNITY_Chess Completion Screen|Chess Completion Screen]]
- [[_COMMUNITY_Chess Mistake Explanation|Chess Mistake Explanation]]
- [[_COMMUNITY_Chess Review Introduction|Chess Review Introduction]]
- [[_COMMUNITY_Partner Handoff Guardrail|Partner Handoff Guardrail]]
- [[_COMMUNITY_Summative Study Package|Summative Study Package]]
- [[_COMMUNITY_Browser QA Automation|Browser QA Automation]]
- [[_COMMUNITY_FIFA Desktop Handoff|FIFA Desktop Handoff]]
- [[_COMMUNITY_Package Builder Code|Package Builder Code]]
- [[_COMMUNITY_Pending Status Explanation|Pending Status Explanation]]
- [[_COMMUNITY_Hi-fi Prototype Requirements|Hi-fi Prototype Requirements]]
- [[_COMMUNITY_Study Introduction Navigation|Study Introduction Navigation]]
- [[_COMMUNITY_PDF Rendering Code|PDF Rendering Code]]
- [[_COMMUNITY_FIFA Order Actions|FIFA Order Actions]]
- [[_COMMUNITY_FIFA Ticket Overview|FIFA Ticket Overview]]
- [[_COMMUNITY_FIFA Ticket Actions|FIFA Ticket Actions]]
- [[_COMMUNITY_FIFA Mobile Handoff|FIFA Mobile Handoff]]
- [[_COMMUNITY_Chess Desktop Mistake|Chess Desktop Mistake]]
- [[_COMMUNITY_FIFA Mobile Status|FIFA Mobile Status]]
- [[_COMMUNITY_FIFA Mobile Orientation|FIFA Mobile Orientation]]
- [[_COMMUNITY_Weekly Report Evidence|Weekly Report Evidence]]
- [[_COMMUNITY_Assignment Requirements|Assignment Requirements]]
- [[_COMMUNITY_Chess Review Start|Chess Review Start]]
- [[_COMMUNITY_FIFA Source Freshness|FIFA Source Freshness]]
- [[_COMMUNITY_PA3 to PA4 Continuity|PA3 to PA4 Continuity]]
- [[_COMMUNITY_Practice Route|Practice Route]]
- [[_COMMUNITY_Better Move Explanation|Better Move Explanation]]
- [[_COMMUNITY_Chess Review Board|Chess Review Board]]
- [[_COMMUNITY_Chess Mobile Review|Chess Mobile Review]]
- [[_COMMUNITY_FIFA Mobile Shell|FIFA Mobile Shell]]
- [[_COMMUNITY_Confirmed Event Summary|Confirmed Event Summary]]
- [[_COMMUNITY_Chess Glossary Help|Chess Glossary Help]]
- [[_COMMUNITY_Chess Scenario Validator|Chess Scenario Validator]]
- [[_COMMUNITY_FIFA Status Summary|FIFA Status Summary]]
- [[_COMMUNITY_Chess Game Context|Chess Game Context]]
- [[_COMMUNITY_FIFA Decision Guidance|FIFA Decision Guidance]]
- [[_COMMUNITY_Shared Navigation Shell|Shared Navigation Shell]]
- [[_COMMUNITY_Source Freshness Cues|Source Freshness Cues]]
- [[_COMMUNITY_Review Metrics|Review Metrics]]
- [[_COMMUNITY_Review Route Steps|Review Route Steps]]
- [[_COMMUNITY_Shared Study Shell|Shared Study Shell]]
- [[_COMMUNITY_Pending Status Explanation|Pending Status Explanation]]
- [[_COMMUNITY_Practice Continuation|Practice Continuation]]
- [[_COMMUNITY_QA Generated Metadata|QA Generated Metadata]]
- [[_COMMUNITY_PDF QA Renderer|PDF QA Renderer]]
- [[_COMMUNITY_Render Manifest|Render Manifest]]
- [[_COMMUNITY_Blank Render Page|Blank Render Page]]
- [[_COMMUNITY_Community 58 Focus|Community 58 Focus]]
- [[_COMMUNITY_Community 59 Focus|Community 59 Focus]]
- [[_COMMUNITY_Community 60 Focus|Community 60 Focus]]

## God Nodes (most connected - your core abstractions)
1. `Group10 PA4 Summative User Study` - 27 edges
2. `AnalysisTests` - 21 edges
3. `analyze()` - 20 edges
4. `Chess desktop practice screenshot` - 18 edges
5. `Group10 PA4 Hi-fi Prototype` - 17 edges
6. `Chess desktop review intro` - 17 edges
7. `Chess desktop completion screenshot` - 16 edges
8. `Chess mobile review` - 16 edges
9. `handleAction()` - 15 edges
10. `FIFA Status Dashboard` - 15 edges
11. `Group10 PA4 Weekly Report` - 14 edges
12. `FIFA desktop order detail screenshot` - 14 edges
13. `External Evidence Blockers` - 13 edges
14. `ORDER DETAIL · FICTIONAL DEMO RECORD` - 13 edges
15. `Chess desktop better-move review screenshot` - 12 edges

## Surprising Connections (you probably didn't know these)
- `Group10 PA4 Hi-fi Prototype report` --renders_to--> `Group10 PA4 Hi-fi Prototype`  [INFERRED]
  source/Group10-PA4-HifiProtype.docx → final/Group10-PA4-HifiProtype.pdf
- `Group10 PA4 Summative User Study report` --renders_to--> `Group10 PA4 Summative User Study`  [INFERRED]
  source/Group10-PA4-SummativeUserStudy.docx → final/Group10-PA4-SummativeUserStudy.pdf
- `Group10 PA4 Weekly Report` --renders_to--> `Group10 PA4 Weekly Report`  [INFERRED]
  source/Group10-PA4-WeeklyReport.docx → final/Group10-PA4-WeeklyReport.pdf
- `PA2 FIFA evidence chains: ticket status clarity, handoff trust, and mobile overview; selected F-A1 Status Dashboard` --semantically_similar_to--> `FIFA Status Dashboard`  [INFERRED] [semantically similar]
  work/pa2-continuity.md → prototype/index.html
- `PA2 Chess evidence chains: entry-choice overload, beginner vocabulary bridge, and practice continuation; selected C-A1 Beginner Review Preset` --semantically_similar_to--> `Chess Beginner Review Flow`  [INFERRED] [semantically similar]
  work/pa2-continuity.md → prototype/index.html
- `Group10 PA4 Hi-fi Prototype` --references--> `FIFA Status Dashboard`  [EXTRACTED]
  final/Group10-PA4-HifiProtype.pdf → memory/continuity/PROJECT_DECISION_CHAIN.md
- `Group10 PA4 Summative User Study` --references--> `FIFA Status Dashboard`  [EXTRACTED]
  final/Group10-PA4-SummativeUserStudy.pdf → memory/continuity/PROJECT_DECISION_CHAIN.md
- `Prototype under test: FIFA Alt 1 Status Dashboard and Chess Alt 1 Beginner Review Flow` --conceptually_related_to--> `FIFA Status Dashboard`  [EXTRACTED]
  final/Group10-PA4-SummativeUserStudy.pdf → memory/continuity/PROJECT_DECISION_CHAIN.md
- `Pre-summative design implications, not PA4 findings` --conceptually_related_to--> `FIFA Status Dashboard`  [EXTRACTED]
  final/Group10-PA4-SummativeUserStudy.pdf → memory/continuity/PROJECT_DECISION_CHAIN.md
- `Group10 PA4 Weekly Report` --references--> `FIFA Status Dashboard`  [EXTRACTED]
  final/Group10-PA4-WeeklyReport.pdf → memory/continuity/PROJECT_DECISION_CHAIN.md

## Hyperedges (group relationships)
- **Review route steps** — chess_desktop_better_move_mistake_step, chess_desktop_better_move_try_step, chess_desktop_better_move_practice_step [EXTRACTED 1.00]
- **Review route steps** — chess_desktop_completion_review_route, chess_desktop_completion_mistake_step, chess_desktop_completion_try_step, chess_desktop_completion_practice_step [EXTRACTED 1.00]

## Communities (61 total, 5 thin omitted)

### Community 0 - "Continuity and Gates"
Cohesion: 0.07
Nodes (43): PA4 acceptance matrix, Local PASS coverage includes selected directions, FIFA/Chess interactions, responsive layouts, study package, browser QA, and packaging; participant, recording, feedback, timing, and YouTube conditions remain BLOCKED EXTERNALLY, PA4 study analysis report, BLOCKED_PARTICIPANT_COUNT; G01-G08 independent gates; zero participant, recording, task, questionnaire, and interview rows; no synthetic findings and descriptive-only timing guardrails, Chess scenario validation, Authoritative legal opening and review state: move 8 White to move, Qa4 mistake, Qc2 better move; legal replay, c3-pawn geometry, and stale-literal checks are recorded, PA4 context audit, PA1-PA3 continuity, PA4 requirements, dependency-free implementation stack, and missing genuine YouTube/participant/recording/task/questionnaire/interview/baseline evidence (+35 more)

### Community 1 - "Study Analyzer Code"
Cohesion: 0.13
Nodes (20): analyze(), build_task_metrics(), clean(), duration_from_row(), interview_gate(), mean_or_blank(), median_or_blank(), parse_float() (+12 more)

### Community 2 - "FIFA Event Overview"
Cohesion: 0.05
Nodes (40): ACTION NEEDED, FIFA.com, FIFA.com / Tickets / Ticket overview, Close, CONFIRMED, Wait with confidence., 01 / 02, Mobile ticket (+32 more)

### Community 3 - "Chess Practice Completion"
Cohesion: 0.05
Nodes (39): Chess desktop trial screenshot, Beginner language, Beginner Review, Chess review board, Highlighted c2 square, Chess / review, Minh's rapid game, Game context (+31 more)

### Community 4 - "Chess Trial Interface"
Cohesion: 0.06
Nodes (38): Complete practice, Need more help, Open review glossary, Return to review, Review another moment, Guided path from explanation to action to practice, Learn from one useful moment, Local demo analysis (+30 more)

### Community 5 - "Chess Prototype Logic"
Cohesion: 0.11
Nodes (37): actionTarget, applyMode(), boardMarkup(), boardPanel(), chessAdvancedModal(), chessHelpModal(), chessPieces, chessScenario (+29 more)

### Community 6 - "Chess Practice Screen"
Cohesion: 0.14
Nodes (35): FIFA desktop overview figure: ticket plan with pending and confirmed events, Chess Beginner Review Flow, One-Mistake Explanation, Better Move, Trial Feedback, and Practice Continuation, PA4 Current State, PA4 Demo Script, Formative, Summative, and Synthetic Evidence Boundary, External Evidence Blockers, FIFA Partner Handoff Guardrail and Return Context (+27 more)

### Community 7 - "Current Memory Documents"
Cohesion: 0.09
Nodes (31): Chess desktop practice screenshot, Beginner language, Beginner Review, Chess.com, Chess / review, Complete practice, Game context, Game Review (+23 more)

### Community 8 - "Report Generation Code"
Cohesion: 0.19
Nodes (29): Document, ListFlowable, Paragraph, generated, build_hifi_docx(), build_hifi_pdf(), build_study_docx(), build_study_pdf() (+21 more)

### Community 9 - "Study Evidence Fields"
Cohesion: 0.09
Nodes (23): gate, duplicate_participant_ids, gates, metadata_issues, minimum_five_verified, missing_recording_participant_ids, participant_rows, recording_checks (+15 more)

### Community 10 - "Chess Completion Screen"
Cohesion: 0.12
Nodes (24): Chess desktop completion screenshot, Beginner language, Beginner Review, Beginner review complete, Chess.com, Chess / review, Game context, Game Review (+16 more)

### Community 11 - "Chess Mistake Explanation"
Cohesion: 0.18
Nodes (19): Beginner language, Better move: Qc2, c2 square, Loose c3 pawn, Chess / review, Game Review, Guided chess review, PA4 / HI-FI LAB (+11 more)

### Community 12 - "Chess Review Introduction"
Cohesion: 0.12
Nodes (18): Review one moment, understand what changed, then try the better move or practice the idea, Start with the most important mistake, Board legend: mistake, better move, your try, Minh's rapid game · Move 8 · White to move · completed rapid game, Game context, Minh's rapid game vs. StudyBot · 10 + 5, Guided review before engine detail, Learn from one useful moment (+10 more)

### Community 13 - "Partner Handoff Guardrail"
Cohesion: 0.12
Nodes (17): Close handoff modal, Continue to partner, Continue to partner, FIFA will not infer transfer completion from returning to this view., This partner preview makes the boundary visible before the action opens. Returning to FIFA.com does not claim that a partner-side transfer is complete., HANDOFF GUARDRAIL · BEFORE YOU LEAVE FIFA.COM, Handoff guardrail · Before you leave FIFA.com, You are about to leave FIFA.com. Continue only if this is the destination you expected. (+9 more)

### Community 14 - "Summative Study Package"
Cohesion: 0.13
Nodes (17): Group10 PA4 Summative User Study, Pre-summative design implications, not PA4 findings, Summative limitations: static fictional data, no live service, no participants or recordings, no controlled baseline, Next action: run the real study, verify evidence, ingest data, rerun analysis, and rebuild the report, Six-step moderated study procedure, Prototype under test: FIFA Alt 1 Status Dashboard and Chess Alt 1 Beginner Review Flow, Five-item 1-5 Likert questionnaire after each product flow, Consented recordings and timestamped interview feedback required for analysis (+9 more)

### Community 15 - "Browser QA Automation"
Cohesion: 0.18
Nodes (16): Context is saved here., Information for this demo is fictional but follows the status, provenance, and boundary pattern from PA2–PA3., FIFA mobile handoff screenshot, FIFA ticket overview screenshot, Last checked: 2 min ago, Your next decision, Partner activity never becomes a claim about ticket completion. Return to this view to re-check the official state., Pending is a real state, not a dead end. The next owner and the last update stay visible while you wait. (+8 more)

### Community 16 - "FIFA Desktop Handoff"
Cohesion: 0.22
Nodes (8): package?, archive_files(), hifi_gate_text(), Build the PA4 working-evidence and minimal official-submission archives.  The wo, require_files(), resolve(), validate_hifi_link_gate(), validate_templates()

### Community 17 - "Package Builder Code"
Cohesion: 0.22
Nodes (10): assertLockedChessBoard(), assertNoHorizontalOverflow(), assertStudyChromeHidden(), check(), countVisibleButtonsWithoutRoutes(), explain, qaDir, screenshotDir (+2 more)

### Community 18 - "Pending Status Explanation"
Cohesion: 0.17
Nodes (12): Exit demo, chess.com, Chess.com / Review / Beginner Review, Chess desktop review intro, Game Review, Chess / review, FIFA / status, Overview (+4 more)

### Community 19 - "Hi-fi Prototype Requirements"
Cohesion: 0.17
Nodes (12): No live FIFA, ticketing, partner, or Chess.com backend, Hi-fi objectives: visible state or learning moment, adjacent actions, observable handoff and recovery, responsive layouts, Coded offline demonstrator with fictional data, Reference layouts: 1440 x 900 and 390 x 844, Study mode hides lab shell and researcher-only controls, Group10 PA4 Hi-fi Prototype, Prototype Browser QA, Chess PA3 Improvements C-IMP-01/02/03/04/08 (+4 more)

### Community 20 - "Study Introduction Navigation"
Cohesion: 0.17
Nodes (12): PA4 external blockers, Group10 real roster: Le Minh; Nguyen Vu Bach; Pham Nguyen Gia Bao; Trang Minh Nhut, Group10 PA4 Weekly Report, Group10 PA4 Weekly Report, Group10 roster/roles, selected FIFA/Chess directions, local artifact work, external blockers, and next session/evidence checkpoint, Named PA4 roles and evidence responsibilities, Local PA4 work completed: audit, prototype, browser QA, study materials, schemas, analysis, builders, and archives, Next checkpoint: confirm ownership, run sessions, verify recordings and feedback, ingest evidence, rerun analysis (+4 more)

### Community 21 - "PDF Rendering Code"
Cohesion: 0.17
Nodes (12): ACTION NEEDED, CONFIRMED, FIFA ticket overview desktop handoff screen, FIFA / status navigation item, YOUR NEXT DECISION, 01 / 02, Offline demo data, PA4 / HI-FI LAB (+4 more)

### Community 22 - "FIFA Order Actions"
Cohesion: 0.18
Nodes (11): Actions stay beside status, Add to Calendar, Save the confirmed event, Common actions, Keep moving without losing context, Order reference & delivery, Ticket detail & event time, Partner destination preview first (+3 more)

### Community 23 - "FIFA Ticket Overview"
Cohesion: 0.18
Nodes (11): Two events, one clear view, Your events, 17 Jun 2026, Group stage · Match 18 · 19:00 local time, Mexico City · Estadio Azteca, Pending · FIFA confirmation, 2 saved, 21 Jun 2026 (+3 more)

### Community 24 - "FIFA Ticket Actions"
Cohesion: 0.18
Nodes (11): Actions stay beside status, Add to Calendar, Common actions, Keep moving without losing context, Order reference & delivery, Partner destination preview first, Save the confirmed event, Ticket detail & event time (+3 more)

### Community 25 - "FIFA Mobile Handoff"
Cohesion: 0.27
Nodes (10): Chess desktop mistake review screenshot, Beginner language notation panel, Better idea: Qc2, Chess review screen, Game context panel, Guided review route, Loose c3 pawn, Move 8: Qa4 mistake (+2 more)

### Community 26 - "Chess Desktop Mistake"
Cohesion: 0.20
Nodes (10): FIFA.com / Tickets / Ticket overview, Chess / review, Exit demo, FIFA.com, ?, PA4 / HI-FI LAB · CSC13112 · interactive study build, Offline demo data, FIFA mobile ticket overview screen (+2 more)

### Community 27 - "FIFA Mobile Status"
Cohesion: 0.22
Nodes (9): Preview Full Analysis, Start Beginner Review, Minh's rapid game · Move 8, We have reduced the review to one useful moment. First understand what changed, then decide whether to try the better move or practice the idea., Start with the most important mistake., Beginner Review explains the why first. Need more help?, START HERE · BEGINNER REVIEW, completed rapid game (+1 more)

### Community 28 - "FIFA Mobile Orientation"
Cohesion: 0.25
Nodes (9): Open review glossary, Beginner language, Loose c3 pawn, Notation, translated., Qa4 means “the queen moved to a4.”, An active-looking queen move that does not help the loose c3 pawn., The useful question is whether that move helps the loose c3 pawn., Notation, translated. (+1 more)

### Community 29 - "Weekly Report Evidence"
Cohesion: 0.22
Nodes (9): Action needed: 0 right now, Confirmed: 1 event ready, Refresh status, Your ticket plan, The fastest way to know what is true now, what happens next, and where an action will take you., 21 Jun 2026, Group stage · Match 27 · 15:00 local time, Toronto · BMO Field (+1 more)

### Community 30 - "Assignment Requirements"
Cohesion: 0.25
Nodes (8): Practice this idea, Review another moment, Guided review, One useful moment, Reason before engine detail, Review route, Practice, Try

### Community 31 - "Chess Review Start"
Cohesion: 0.36
Nodes (8): REVIEW BOARD, You played, Move 8 · Queen move, 8. Qa4, Opening position · Move 8, Mistake, Your try, Review board

### Community 32 - "FIFA Source Freshness"
Cohesion: 0.25
Nodes (8): Beginner Review, chess.com, Chess mobile review, Local demo analysis, Offline demo data, Step 1 of 3, Chess / review, PA4 / HI-FI LAB

### Community 33 - "PA3 to PA4 Continuity"
Cohesion: 0.25
Nodes (8): PA4 Assignment Brief, Requirement 3: Presentation and Demo, Summative study requirement: feedback and task timing data, Summative study requirement: at least five participants, Requirement 1: High-fidelity prototype, Requirement 2: Summative User Study, Summative study requirement: video-record all testing sessions, Requirement 4: Weekly Report

### Community 34 - "Practice Route"
Cohesion: 0.29
Nodes (7): contentType(), imagePath, pageErrors, pdfjsRoot, runtimeNodeModules, serveFile(), server

### Community 35 - "Better Move Explanation"
Cohesion: 0.25
Nodes (8): FIFA confirms the allocation., Awaiting confirmation, Current status: Pending, Owner: FIFA, Last updated: 2 min ago, Expected timing: next confirmation update, No action needed, FIFA is confirming the allocation for your Mexico City match. Your place is not lost, and no action is required from you right now.

### Community 36 - "Chess Review Board"
Cohesion: 0.25
Nodes (8): Your events, 17 Jun 2026, Group stage · Match 18 · 19:00 local time, Mexico City · Estadio Azteca, Pending · FIFA confirmation, Pending: 1 awaiting confirmation, 2 saved, Two events, one clear view

### Community 37 - "Chess Mobile Review"
Cohesion: 0.32
Nodes (8): DEMO DATA, Exit demo, FIFA.com, DEMO DATA, FIFA.com Tickets, Help (?), Stay on FIFA.com, Tickets

### Community 38 - "FIFA Mobile Shell"
Cohesion: 0.52
Nodes (6): fail(), path_clear(), Validate the legal Chess review position used by the PA4 prototype.  The prototy, replay_opening(), semantic_checks(), source_audit()

### Community 39 - "Confirmed Event Summary"
Cohesion: 0.33
Nodes (6): Awaiting confirmation, Current status, Last updated: 2 min ago, No action needed, FIFA is confirming the allocation for your Mexico City match. Your place is not lost, and no action is required from you right now., Pending

### Community 40 - "Chess Glossary Help"
Cohesion: 0.33
Nodes (6): Action needed: 0 right now, Confirmed: 1 event ready, Pending: 1 awaiting confirmation, Refresh status, Your ticket plan, The fastest way to know what is true now, what happens next, and where an action will take you.

### Community 41 - "Chess Scenario Validator"
Cohesion: 0.33
Nodes (6): Game review, Minh's rapid game, vs. StudyBot · 10 + 5, StudyBot, A guided review for players who want the reason before the engine detail., Learn from one useful moment

### Community 42 - "FIFA Status Summary"
Cohesion: 0.40
Nodes (5): 01 / 02, Your next decision, Pending is a real state, not a dead end. The next owner and the last update stay visible while you wait., Read the status definition, Wait with confidence.

### Community 43 - "Chess Game Context"
Cohesion: 0.60
Nodes (5): Game context, 8 key move, 1 learning moment, +1 practice path, GAME CONTEXT

### Community 44 - "FIFA Decision Guidance"
Cohesion: 0.60
Nodes (5): Start with the most important learning moment from this game. Advanced analysis stays one click away., REVIEW ROUTE, 1 · Mistake, 3 · Practice, 2 · Try

### Community 45 - "Shared Navigation Shell"
Cohesion: 0.40
Nodes (5): Chess desktop mistake figure: move 8 Qa4 and safer Qc2 learning moment, Suggested Better Move, Glossary and Optional Full Analysis Help, Plain-Language Mistake Explanation, Single Learning Moment

### Community 46 - "Source Freshness Cues"
Cohesion: 0.40
Nodes (5): Chess / review, PA4 / HI-FI LAB shell, FIFA / status, Offline demo data, Overview

### Community 47 - "Review Metrics"
Cohesion: 0.50
Nodes (4): Information shown for this demo is fictional but follows the status, provenance, and boundary pattern from PA2–PA3., Last checked: 2 min ago, Preview unavailable state, Source & freshness

### Community 48 - "Review Route Steps"
Cohesion: 0.50
Nodes (4): Context is saved here., Partner activity never becomes a claim about ticket completion. Return to this view to re-check the official state., Reset demo state, Return orientation

### Community 49 - "Shared Study Shell"
Cohesion: 0.50
Nodes (4): FIFA desktop handoff figure: partner destination preview modal, Before-You-Leave FIFA.com Guardrail, External Partner Boundary, Preserved Context and Return Route

### Community 50 - "Pending Status Explanation"
Cohesion: 0.50
Nodes (4): Show the better move, Better idea, Qc2, Better move

### Community 51 - "Practice Continuation"
Cohesion: 0.67
Nodes (3): FIFA confirms the allocation., Owner: FIFA, Expected timing: next confirmation update

### Community 52 - "QA Generated Metadata"
Cohesion: 0.67
Nodes (3): Chess desktop practice figure: guided practice route, Practice This Idea Continuation, Recoverable Trial Feedback

### Community 53 - "PDF QA Renderer"
Cohesion: 0.67
Nodes (3): Summative study status: BLOCKED EXTERNALLY; 0 verified participant sessions; no simulated results, Participant sessions and outcome evidence externally blocked; future work planned, Header-Only PA4 Study CSVs

## Knowledge Gaps
- **350 isolated node(s):** `fifaEvents`, `fifaState`, `chessState`, `chessScenario`, `chessPieces` (+345 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **5 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Group10 PA4 Summative User Study` connect `Summative Study Package` to `Continuity and Gates`, `PA3 to PA4 Continuity`, `Chess Practice Screen`, `Report Generation Code`, `Hi-fi Prototype Requirements`, `Study Introduction Navigation`, `PDF QA Renderer`?**
  _High betweenness centrality (0.019) - this node is a cross-community bridge._
- **Why does `Group10 PA4 Hi-fi Prototype` connect `Hi-fi Prototype Requirements` to `Continuity and Gates`, `PA3 to PA4 Continuity`, `Chess Practice Screen`, `Report Generation Code`, `Summative Study Package`?**
  _High betweenness centrality (0.019) - this node is a cross-community bridge._
- **Why does `Group10 PA4 Hi-fi Prototype report` connect `Continuity and Gates` to `Hi-fi Prototype Requirements`?**
  _High betweenness centrality (0.012) - this node is a cross-community bridge._
- **Are the 3 inferred relationships involving `Group10 PA4 Summative User Study` (e.g. with `Requirement 2: Summative User Study` and `Group10 PA4 Hi-fi Prototype`) actually correct?**
  _`Group10 PA4 Summative User Study` has 3 INFERRED edges - model-reasoned connections that need verification._
- **Are the 11 inferred relationships involving `analyze()` (e.g. with `.test_t01_zero_participants_is_blocked()` and `.test_t02_four_complete_participants_are_blocked_by_count()`) actually correct?**
  _`analyze()` has 11 INFERRED edges - model-reasoned connections that need verification._
- **Are the 4 inferred relationships involving `Group10 PA4 Hi-fi Prototype` (e.g. with `Requirement 1: High-fidelity prototype` and `Two Offline Hi-Fi Prototypes and Summative Package`) actually correct?**
  _`Group10 PA4 Hi-fi Prototype` has 4 INFERRED edges - model-reasoned connections that need verification._
- **What connects `fifaEvents`, `fifaState`, `chessState` to the rest of the system?**
  _358 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Continuity and Gates` be split into smaller, more focused modules?**
  _Cohesion score 0.06755260243632337 - nodes in this community are weakly interconnected._
- **Should `Study Analyzer Code` be split into smaller, more focused modules?**
  _Cohesion score 0.13472706155632985 - nodes in this community are weakly interconnected._
- **Should `FIFA Event Overview` be split into smaller, more focused modules?**
  _Cohesion score 0.052564102564102565 - nodes in this community are weakly interconnected._